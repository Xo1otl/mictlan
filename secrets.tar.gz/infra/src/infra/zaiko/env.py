DB_PASSWORD = "zaiko_password"
