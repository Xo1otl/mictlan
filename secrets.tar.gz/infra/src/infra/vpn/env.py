from infra import ecosystem

FQDN = f"vpn.{ecosystem.DOMAIN}"
UDP_PORT = "1234"
WEBUI_PASSWORD_HASH = "$$2a$$12$$.s5xN0vC4p3h.WfHnGUWXuHZnjJL0pAr6KuGnb24wPeetXdX4zw0y"
WEBUI_PORT = "2345"
ALLOWED_IPS = "10.8.0.0/24"
