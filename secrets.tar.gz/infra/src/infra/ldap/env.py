ADMIN_USER = "uid=admin,ou=people,dc=mictlan,dc=site"
LLDAP_JWT_SECRET = "CeMjbwfILBnaYm6jQIXH-A6lRfzUDJw-JgquSPs9x6c"
LLDAP_KEY_SEED = "oiashoioehfaoei1273468gia8721"
LLDAP_LDAP_USER_PASS = "UfudjcjJ746*"
