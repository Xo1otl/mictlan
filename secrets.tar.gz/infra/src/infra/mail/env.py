RSPAMD_PORT = 11334
RELAY_USER = "xolotl.mictl4n@gmail.com"
RELAY_PASSWORD = "vjtq gdfk ggkc fthl"
ADMIN_USERNAME = "xolotl@mictlan.site"
ADMIN_PASSWORD = "UfudjcjJ746*"
