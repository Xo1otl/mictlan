MEILI_MASTER_KEY = "meili-master-key"
