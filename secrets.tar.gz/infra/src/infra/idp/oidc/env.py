# See the README for more information: https://github.com/stonith404/pocket-id?tab=readme-ov-file#environment-variables

MAXMIND_LICENSE_KEY = "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"
