MYSQL_USER = 'akinator'
MYSQL_DB = 'akinator_db'
MYSQL_PASSWORD = 'akinator_password'
